## fistaszjoObwatel 4.2.0 

Uwaga! Ten projekt służy jedynie jako pamiątka kolekcjonerska. Dawanie linku bez zgody właściciela jest zabronione.

![on patrzy](https://cdn.discordapp.com/attachments/1323384145602285619/1334984546629849188/caption.gif?ex=690bb43e&is=690a62be&hm=bcb847377950beb6bfa413503d4af2412233be3bb9ca941ffdd71c2d0f342194&)

### Instrukcja zainstalowania:


#### Dla systemu IOS:
- Upewnij się, że używasz przeglądarki Safari
- Uzupełnij dane i kliknij wejdź
- Naciśji udostępnij -> Do Ekranu głównego
#### Dla systemu Android:
- Upewnij się, że używasz przeglądarki google lub chrome
- Uzupełnij dane i kliknij wejdź
- Naciśji 3 kropki -> Dodaj do ekranu głównego

Miłego chlania i jarania.
